import networkx as nx
import random
import matplotlib.pyplot as plt

def create_node(G):
    G = nx.Graph()
    G.add_nodes_from(range(1,101))
    #for i in range(1,101):
    #G.add_node(i)
    return G
#assign as body mass index to every person
def assign_BMI(G):
    #number from 15 to 40 and assign it generate that random number
    #one people other social
    #using attribute
    for each in G.nodes():
        G.node[each]['name'] = random.randint(15,40)
        G.node[each]['type'] = 'person'

def get_colours(G):
    c = []
    for each in G.nodes():
        if G.nodes[each]['type'] == 'person':
            if G.node[each]['name'] == 15:
                c.append('green')
            elif G.node[each]['name'] == 40:
                c.append('yellow')
            else:
                c.append('blue')
        else:
            c.append('red')
    return c
def get_foci_nodes(G):
    f = []
    for each in G.nodes():
        if G.nodes[each]['type'] == 'foci':
            f.append(each)
        return f
def add_foci_nodes()
def add_foci_edges(G):
    foci_nodes = get_foci_nodes()
    person_nodes = get_persons_nodes(G)
    for each in person_nodes:
        r = random.choice(foci_nodes)
        G.add_edge(each,r)
def get_labels(G):
    dict = {}
    for each in G.nodes():
        dict[each] = G.nodes[each]['name']
    return dict
labeldict = get_labels(G)
#difference
def get_size(G):
    #size of differnt nodes
    for each in G.nodes():
        array1.append(G.nodes[each]['name']*20)#scale the value so that graph or nodes looks distinguishable.
    return array1
def get_persons_nodes(G):
    p = []
    for each in G.nodes():
        if G.nodes[each]['type'] == 'person':
            p.append(each)
    return p

def homophily(G):
    p = get_persons_nodes(G)
    for u in p:
        for v in p:
            if u!=v:
                diff_in_bmi = abs(G.node[u]['name']-G.node[v]['name'])
                p = float(1/(diff+1000))
                r = random.uniform(0,1)
                if(r<p):
                    G.add_edge(u,v)
nsize = get_size(G)

nx.draw(G,labels = labeldict,node_size = nsize)#remove the labels...we can tell with the size of node whether having large BMI or small

#checking homophily
#more is the probability if the BMI difference is less thus more homophily
