import networkx as nx
import random
import matplotlib.pyplot as plt
import numpy as np

#for finding the number of nodes and edges
#for calculating the average degree
#for finding the clustering coefficient
def analyse_network(G):
    N = G.order #nx.number_of_nodes(G)
    E = G.size #nx.number_of_edges(G)
    print("Number of nodes= ",N)
    print("Number of edges= ",E)
    #A = 1/N(sum(ki))while i goes from 1 to N
    # another way A = 2E/N
    all_degrees = nx.degree(G).values()
    unique_degree = list(set(all_degrees))
    for i in range(N):
        sum_of_degrees += unique_degree[i]
    average = sum_of_degree/N
    print("Average Degree=",average)
    #average clustering coefficient
    #nx.clustering(G)
    for i in  nx.clustering(G).items():#clustering coefficent values for each node
        print(i)
    print(nx.average_clustering(G))

# for adding the random edge
# could have done other way as well
#in the function find_num_edge
#in while loop can used this as
#G = nx.add_edge(random.choice(G.nodes),random.choice(G.nodes))
'''def add_random_edge(G):
e1 = random.choice(G.nodes())
e2 = random.choice(G.nodes())
if(e1!=e2):
    G.add_edges(e1,e2)
return'''
#first used the above method then changed it
#the above method can also be used
def find_num_edges(G):
    while(nx.is_connected(G) == False):
        G = nx.add_edge(random.choice(G.nodes),random.choice(G.nodes))
    E = G.number_of_edges(G)
    print("Number of edges=",E)

#using Girvan Newman algorithm.
#this is the extra function for finding the edge to remove
def edge_to_remove(G):
    dict1 = nx.edge_betweeness_centrality(G)
    list_of_tuples = dict1.items()
    list_of_tuples.sort(key = lambda x:x[1],reverse = True)
    return list_of_tuples
#here to find the number of the communities 
def find_num_comm(G):
    comp = nx.connected_componet_subgraph(G)
    l = len(comp)
    #print("The number of connected components:",l)
    while(l==1):
        G.remove_edge(*edge_to_remove(G))
        comp = nx.connected_componet_subgraph(G)
        l = len(comp)
        #print("The number of connected components:",l)
    print("Number of communities=",c)
    
