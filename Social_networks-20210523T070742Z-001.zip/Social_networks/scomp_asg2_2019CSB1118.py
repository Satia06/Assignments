import networkx as nx
import random
import matplotlib.pyplot as plt
#function to see homophly
#should return two values
#initial number of the edges
# updated number of edges
def get_nodes(G):
    p = []
    for each in G.nodes:
        if G.node[each]['type'] == 'int':
            p.append(each)
    return p
def homophily(G):
    p = get_nodes(G)
    a = len(list(G.edges()))
    for u in p:
        for v in p:
            if u!=v:
                #checking the homophily
                #more is the probability if the BMI difference is less thus more homophily
               diff_in_bmi = abs(G.node[u]['name']-G.node[v]['name'])
               #why add 1000?to reduce the scale
                d = float(1/(diff_in_bmi+1000))
                r = random.uniform(0,1) 
                if(r<d):
                    G.add_edge(u,v)
    new_edges = len(list(G.edges()))
    print(a,new_edges)
# returns the two values of the old edges and newedges
#while newedges are added on the based of the closure
def closure(G):
    f_closure = []
    a = len(list(G.nodes()))
    for u in G.nodes():
        for v in G.nodes():
            if(u!=v and (G.node[u]['type'] == 'person' or G.node[v]['type']=='person'):
               c = len(list(nx.common_neighbors(G,i,j)))
               p = 1-(1-0.01)**c
               f_closure.append([i,j,p])
    for i in f_closure:
        r = random.uniform(0,1)
        if(i[2]>r):
            G.add_edge(i[0],i[1])
    n_edges =len(list(G.edges()))
    print(a,n_edges)
#returns again the two values
#one is the normal number of the nodes before updating and having the value as 40
#other value is the number of the nodes after updating and having value as 40
#updating the values if eat_out then we check the neighbours and then adding them  
def change_bmi(G):
    a = 0
    b = 0
    for i in G.nodes():
        if(G.nodes[i]['name'] == 40):
            a = a+1
    for i in G.nodes():
        if(G.nodes[i]['name'] =='eat_out'):
            neighbour = list(nx.neighbors(G,i)
            break
    for i in neighbour:
        G.nodes[i]['name'] = G.nodes[i]['name']+1
    for i in G.nodes():
        if(G.nodes[i]['name']==40):
            b = b+1
    print(a,b)
        
    
