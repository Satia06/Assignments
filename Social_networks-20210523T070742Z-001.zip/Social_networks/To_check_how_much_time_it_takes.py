#to know how much time it takes to cover all the vertices in random walk
#entire graph
import random 
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

def walk(n,p):#generate a random graph with n nodes and p vertices
#start from a random vertex and keep walking and count how much time it takes
    
    start = random.randint(0,n-1)
    G = nx.erdos_renyi_graph(n,p)
    S = set([])
    v = start
    count = 0
    while(len(S)<n):
        Nbr = nx.neighbors(G,v)
        v = random.choice(Nbr)
        S.add(v)
        count = count +1
        return count
l = []
for i in range(20,1000):#call walk quite often
    z = []
    for j in range(10):
        z.append(walk(i,0.3))#number ofrandom walk to finish going to given vertices
    l.append(np.average(z))
    print(i,"--->",np.average(z))
plt.plot(l)
plt.show()
