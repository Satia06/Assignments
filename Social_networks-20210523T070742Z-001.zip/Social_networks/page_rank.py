import networkx as nx
import random
import numpy as np
import matplotlib.pyplot as plt

#after every iteration pts collected By each node  have keep changing
#however after one such iteration the collected coins wont change
def add_edges(G,p):
    for i in G.nodes():
        for j in G.nodes():
            if i!= j:
                r = random.random()
                if r <=p:
                    G.add_edge(i,j)
                else:
                    continue
    return G

#create a directed graph with n nodes
def main():
    G = nx.DiGraph()
    G.add_nodes_from([i for i in range(10)])
    G = add_edges(G,0.3)
def initialize_points(G):
    points = [100 for i in range()]
    return points
def handle_points_sink(G,points):
    for i in range(len(points)):
        points[i] = (float)(points[i])*0.8
    n = G.number_of_nodes()
    extra = (float)(n*100*0.2)/n
    for i in range(len(points)):
        points[i] += extra
    return points
def distribute_points(G,points):
    prev_p = points
    new_p = [0 for i in range(G.number_of_nodes())]
    for i in G.nodes():
        out = G.out_edges(i)
        if len(out) == 0:
            new_p[i] += prev_p[i]
        else:
            share = (float)(prev_p[i])/len(out)
            for each in out:
                new_p[each[1]] += share
    return(G,new_p)
def keep_distributing_points(G,points):
    prev_points = points
    print('ENter # to stop')
    while(1):
        G,new_points = distribute_points(G,prev_points)
        print new_points

        new_points = handle_points_sink(G,new_points)
        
        char = raw_input()
        if char == '#':
            break
        prev_points = new_points
    return G,new_points
def get_nodes_sorted_by_points(points):#get_nodes_sorted_by_RW
    points_array = np.array(points)
    nodes_sorted_by_points = np.argsort(points_array)
    return nodes_sorted_by_points

#assign 100 points to each node
points = initialize_points(G)
#keep distributing until convergence
G,points= keep_distributing_points(G,points)
#get nodes ranking as per the points accumulated
nodes_sorted_by_points = get_nodes_sorted_by_points(points)
print('nodes_sorted_by_points ',nodes_sorted_by_points )
#compare the ranks thus obtained from the inbuilt page rank method
pr = nx.pagerank(G)
pr_sorted = sorted(pr.items(),key = lambda x:s[1],reverse = True)
for i in pr_sorted:
    print i[0]
    
#implementing page rank using the random walk
RW_points = random_walk(G)

def random_walk(G):
    nodes = G.nodes()
    RW_points = [0 for i in range(G.number_of_nodes())]
    r = random.choice(nodes)
    RW_points[r] +=1
    out = G.out_edges(r)
    #repeating it as much as possible
    c = 0
    while(c!=100000):
        #visit all the nodes.
        #not rank the nodes properly
        #frequency of visiting
        #len(out) = 0?teleportation
        if(len(out) == 0):
            focus = random.choice(nodes)
        else:
            r1 = random.choice(out)
            focus = r1[1]#NODE AT THE other side
        RW_points[focus] += 1
        out = G.out_edges(focus)
        c += 1
    return RW_points

#MISMATCH RAnk od 4 and 6 may be same or we need to do more iterations
#probability.
#DegreeRank vs PageRank
#citation network

def main():
    G = nx.read_edgelist('citation.txt',create_using = nx.DiGraph())
    deg = G.in_degree()
    pr = nx.pagerank(G)

    pr_values = []

    for i in deg.keys():
        pr_values.append(pr[i])
    plt.plot(deg.values(),pr_values,'ro',markersize = 3)
    plt.xlabel('Degrees of the nodes')
    plt.ylabel('Page Rank Values  of the nodes')

    plt.show()
#not correlated with each other some nodes have high indeg
# but less page rank
