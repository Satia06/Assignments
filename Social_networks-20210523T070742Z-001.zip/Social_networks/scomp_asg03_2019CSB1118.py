import networkx as nx
import matplotlib.pyplot as plt
import random as rd

#Creating grid graph
def create_graph(N):
    return nx.grid_2d_graph(N, N)

#Adding diagonal edges
def add_diagonal_edges(G):
    for (u, v) in G.nodes():
        if (u+1 <= N-1) and (v+1 <= N-1):
            G.add_edge((u, v), (u+1, v+1))

    for (u, v) in G.nodes():
        if (u+1 <= N-1) and (v-1 >= 0):
            G.add_edge((u, v), (u+1, v-1))
    return


#Assigning Type to every node as either 0,1 or 2
def assign_type(G):
    for n in G.nodes():
        G.node[n]['type'] = rd.randint(0, 2)

#Returns boundary nodes as well as internal nodes of the grid graph, do not print simply return two list of nodes, first should be
#list of boundary nodes and other should be list of internal nodes
def get_boundary_internal_nodes(G,N):
    boundary_nodes = []
    for((u,v),d) in G.nodes(data = True):
        if(u == 0 or u == N-1 or v == 0 or v == N-1):
            boundary_nodes.append(u,v)
    internal_nodes = list(set(G.nodes)-set(boundary_nodes))
    return boundary_nodes,internal_nodes

def get_internal_neigh(u,v):
    return [(u-1,v),(u+1,v),(u,v-1),(u,v+1),(u-1,v-1),(u+1,v+1),(u-1,v+1),(u+1,v-1)]
def get_boundary_neigh(u,v,N):
    if u == 0 and v == 0:
        return [(0,1),(1,1),(1,0)]
    elif u == N-1 and v == N-1:
        return [(N-2,N-2),(N-1,N-2),(N-2,N-1)]
    elif u == N-1 and v ==0:
        return [(u-1,v),(u,v+1),(u-1,v+1)]
    elif u == 0 and v == N-1:
        return [(u+1,v),(u+1,v-1),(u,v-1)]
    elif u == 0:
        return [(u,v-1),(u,v+1),(u+1,v),(u+1,v-1),(u+1,v+1)]
    elif u == N-1:
        return [(u-1,v),(u,v-1),(u,v+1),(u-1,v+1),(u-1,v-1)]
    elif v == N-1:
        return [(u,v-1),(u-1,v),(u+1,v),(u-1,v-1),(u+1,v-1)
    elif v == 0:
        return [(u-1,v),(u+1,v),(u,v+1),(u-1,v+1),(u+1,v+1)]
        
def get_unsatisfied_nodes_list(G,N,t):
    unsatisfied_nodes_list = []
    b_nodes,i_nodes = get_boundary_internal_nodes(G,N)
    for u,v in G.nodes():
        type_of_this_node = G.node[(u,v)]['type']
        if type_of_this_nodes == 0:
            continue
        else:
            similar_nodes = 0
            if(u,v) in i_nodes:
                neigh = get_internal_neigh(u,v)
            elif(u,v) in b_nodes:
                neigh = get_boundary_neigh(u,v,N)

            for each in neigh:
                if G.node[each]['type'] = type_of_this_node:
                    similar_nodes +=1
            if similar_nodes <= t:
                unsatisfied_node_list.append(u,v)
    return unsatisfied_node_list

    
#Returns only the number of unsatisfied nodes out of all the given nodes in the graph, and not the list of all those nodes, where G is a graph of size N*N and t is the threshold for deciding satisfiability of the node.
def num_unsatified_nodes_list(G,N,t):
    unsatisfied_nodes_list = get_unsatisfied_nodes_list(G,N,t)
    number_of_unsatisfied_nodes = len(unsatisfied_nodes_list)        
    return number_of_unsatisfied_nodes

print("2019CSB1118")
