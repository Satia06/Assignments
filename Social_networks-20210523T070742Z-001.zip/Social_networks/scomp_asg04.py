import networkx as nx
import random
import numpy as np
#Creating empty graph, adding 'N' nodes and some edges based on the probability 'p'
def create_graph(N,p):
    G = nx.DiGraph()#empty graph
    G.add_nodes_from([i for i in range(N)])
    for i in G.nodes():
        for j in G.nodes():
            if i != j:
                r = random.random()
                if r <= p:
                    G.add_edge(i, j)
                else:
                    continue
    return G

def initialize_points(G):
    points = [100 for i in range(G.number_of_nodes())]
    return points

#Implement the function for distribution of points by each node to its outlinks
def distribute_points(G, points):
    prev_p = points
    new_p = [0 for i in range(G.number_of_nodes())]
    for i in G.nodes():
        out = G.out_edges(i)
        if len(out) == 0:
            new_p[i] += prev_p[i]
        else:
            share = (float)(prev_p[i])/len(out)
            for each in out:
                new_p[each[1]] += share
    return(G,new_p)

##Implement the function for handling the case of sink nodes by collecting 20% of points from
#each node as given in video lectures
def handle_points_sink(G, points):
    for i in range(len(points)):
        points[i] = (float)(points[i])*0.8
    n = G.number_of_nodes()
    extra = (float)(n*100*0.2)/n
    for i in range(len(points)):
        points[i] += extra
    return points



def keep_distibuting_points(G, points):
    prev_points = points
    iter=1
    no_change=0
    while(no_change==0 and iter<=100):
        G, new_points = distribute_points(G, prev_points)
        #print(new_points)
        ##
        new_points = handle_points_sink(G, new_points)
        new_points=[round(pt,4) for pt in new_points]
        if prev_points==new_points:
            no_change=1
            prev_points = new_points
            iter+=1
        if no_change==1:
            print('Total iterations = ',iter)
        else:
            print('Total iterations = ',iter-1)
    return G, new_points

#Returns the sorted nodes based on the points in descending order
def get_nodes_sorted_by_points(points):
    points_array = np.array(points)
    nodes_sorted_by_points = np.argsort(points_array)
    return nodes_sorted_by_points

# Assign 100 points to each node.
points = initialize_points(G)
    
# Keep distributing points until convergence.
G, points = keep_distibuting_points(G, points)
    
# Get nodes' raking as per the points accumulated
nodes_sorted_by_points = get_nodes_sorted_by_points(points)
print('Nodes sorted by Points Distribution Method : ', ' '.join(map(str,nodes_sorted_by_points)))
    
# Compare the ranks thus obtained with the ranks obtainrd from the inbuilt Page rank method
pr = nx.pagerank(G)# Return a dictionary
pr_sorted = sorted(pr.items(), key = lambda x:x[1], reverse = True)

inbuilt_node_list=[]
for i in pr_sorted:
    inbuilt_node_list.append(i[0])
    
print('Nodes sorted by Inbuilt Page Rank Method: ',' '.join(map(str,inbuilt_nodes_list)))


print('2019CSB1118')
