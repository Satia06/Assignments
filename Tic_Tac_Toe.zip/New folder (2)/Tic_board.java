import java.util.Arrays;

public class Tic_board {
    static String[] tic_board;

    Tic_board(){
        tic_board = new String[9];
        Arrays.fill(tic_board, " ");
    }

    String[] getBoard(){
        return tic_board;
    }

    void setPosition(int position, String symbol){
        tic_board[position-1] = symbol;
    }

    boolean checkOccupancy(int position){   //returns true if a position is occupied
        if(!tic_board[position-1].equals(" ")){
            return true;
        }
        else{
            return false;
        }
    }

    void display(){
        System.out.println(tic_board[0] + " | " + tic_board[1] + " | " + tic_board[2]);
        System.out.println(tic_board[3] + " | " + tic_board[4] + " | " + tic_board[5]);
        System.out.println(tic_board[6] + " | " + tic_board[7] + " | " + tic_board[8]);
    }

    boolean isBoardFilled(){
        boolean isFilled = true;
        for(int i = 0; i<9 ; i++){
            if(tic_board[i].equals(" ")){
                isFilled = false;
                break;
            }
        }
        return isFilled;
    }

    int checkWinner(){  //returns 0 if draw, -1 if not finished yet and 1 if player 1 wins, 2 if player 2 wins
		for (int i = 1;i<=8;i++){
            String Tac_line = null;
            switch(i){                                   
				case 1:
					Tac_line = tic_board[0] + tic_board[1] + tic_board[2];
					break;
				case 2:
					Tac_line = tic_board[3] + tic_board[4] + tic_board[5];
					break;
				case 3:
					Tac_line = tic_board[6] + tic_board[7] + tic_board[8];
					break;
				case 4:
					Tac_line = tic_board[0] + tic_board[4] + tic_board[8];
					break;
				case 5:
					Tac_line = tic_board[2] + tic_board[4] + tic_board[6];
					break;
				case 6:
					Tac_line = tic_board[0] + tic_board[3] + tic_board[6];
					break;
				case 7:
					Tac_line = tic_board[1] + tic_board[4] + tic_board[7];
					break;
				case 8:
					Tac_line = tic_board[2] + tic_board[5] + tic_board[8];
					break;
			}
            if(Tac_line.equals("XXX")){
                return 1;
            }
            else if(Tac_line.equals("OOO")){
                return 2;
            }
            else{
                continue;
            }
		}
        
        if(isBoardFilled()){
            return 0;
        }
        else{
            return -1;
        }
    }
    static String getelement(int row, int column){
        return tic_board[row*3 + column];
    }
    static void Setelement(int row, int column,String symbol){
        tic_board[row*3 + column] = symbol;
    }
}
