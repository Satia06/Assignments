import java.util.*;
public class ComputerVsPlayer{
    static Tic_board board;
    static int chance;
    static String symbol;

    ComputerVsPlayer(){
        board = new Tic_board();
    }
    int turn(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Player " + chance + "'s turn;\nChoose the position:");
        int position = sc.nextInt();
        return position;
    }
    static boolean isWinning(String symbol){
        for(int i = 0;i <=2;i++){
            if(board.getelement(i,0).equals(symbol) && board.getelement(i,1).equals(symbol) && board.getelement(i,2).equals(symbol)){
                return true;
            }
        }
        for(int j = 0;j<=2;j++){
            if(board.getelement(0,j).equals(symbol) && board.getelement(1,j).equals(symbol) && board.getelement(2,j).equals(symbol)){
                return true;
            }
        }
        if(if(board.getelement(0,0).equals(symbol) && board.getelement(1,1).equals(symbol) && board.getelement(2,2).equals(symbol)){
            return true;
        }
        if(board.getelement(0,2).equals(symbol) && board.getelement(1,1).equals(symbol) && board.getelement(2,0).equals(symbol)){
            return true;
        }
        return false;
    }

    public static int ComputerMove(){
        //winning  move
        for(int row = 0; row<= 2; row++){
            for(int column = 0; column<= 2; column ++){
                if(board.getelement(row,column).equals(" ")){
                    board.Setelement(row,column,"O");
                
                    if(isWinning("O") == true){
                        return row*3 + column;
                    }
                    else{
                        board.Setelement(row,column," ");
                    }
                }
            }
        }
        //blocking move
        for(int row = 0; row<= 2; row++){
            for(int column = 0; column<= 2; column ++){
                if(board.getelement(row,column).equals(" ")){
                    board.Setelement(row,column,"O");
                
                    if(isWinning("X") == true){
                        return row*3 + column;
                    }
                    else{
                     board.Setelement(row,column," ");
                    }
                }
            }
        }
        if(board.getelement(1,1).equals(" ") ){
            return 1*3+1;
        }
        if(board.getelement(0,0).equals(" ") ){
            return 0*3+0;
        }
        if(board.getelement(0,2).equals(" ") ){
            return 0*3+2;
        }
        if(board.getelement(2,0).equals(" ") ){
            return 2*3+0;
        }
        if(board.getelement(2,2).equals(" ") ){
            return 2*3+2;
        }
        for(int row = 0;row<=2; row++){
            for(int column = 0;column <= 2; column++){
                if(board.getelement(row,column).equals(" ") ){
                    return row*3 + column;
                }
            }
        }
        return -1;
    }

    void GameLoop(){
        chance = 1;
        while(true){
            switch(chance){
                case 1:{
                    symbol = "X";
                    int position = Turn();
                    if(!tic_board.checkOccupancy(position)){
                        tic_board.setPosition(position,symbol);
                        chance = 2;
                    }
                    else{
                        System.out.println("The entered position is already filled. Try again!");
                        chance = 1;
                    }
                    break;
                }
                case 2:{
                    symbol = "O";
                    int position = ComputerMove();
                    tic_board.setPosition(position,symbol);
                    chance = 1;
                    break;
                }
                default: break;
            }
            tic_board.display();
            int outcome = tic_board.checkWinner();
            
            switch(outcome){
                case -1:{
                    break;
                }
                case 0:{
                    System.out.println("The game is a draw!");
                    return;
                }
                case 1:{
                    System.out.println("You won. Congratulations!");
                    return;
                }
                case 2:{
                    System.out.println("Computer won.");
                    return;
                } 
            }   
        }
    }
}
