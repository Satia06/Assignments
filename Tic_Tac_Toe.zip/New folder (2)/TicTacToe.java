import java.util.*;
//player 1 always has X and plays first. while player 2 always has O
public class TicTacToe {
    public static void main(String[] args) throws Exception {
        Scanner sc=new Scanner(System.in);

        System.out.println("Welcome to the Tic-Tac-Toe game!");
        System.out.println("Please select the game mode:\nEnter 1 for Player Vs Player mode\nEnter 2 for Player Vs Computer mode");
        int gameMode = sc.nextInt();
        
        while(true){
            switch(gameMode){
                case 1:     PlayerToPlayer ptp = new PlayerToPlayer();
                            ptp.GameLoop();
                            break;
                case 2:     ComputerVsPlayer cvp = new ComputerVsPlayer();
                            cvp.GameLoop();
                            break;
                default:    System.out.println("Thank you for playing!");
                            break;
            }
            System.out.println("Do you want to continue[y/n]?:")
            char ask = sc.next().charAt(0);
            if(ask == 'y'){
                System.out.println("Please select the game mode:\nEnter 1 for Player Vs Player mode\nEnter 2 for Player Vs Computer mode");
                gameMode = sc.nextInt();
                continue;
            }
            else{
                break;
            }
        }
        
        sc.close();
    }
}
