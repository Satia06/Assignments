import java.util.*;

public class PlayerToPlayer{
	static Tic_board tic_board;
	static int chance;
    static String symbol;

    PlayerToPlayer(){
        tic_board = new Tic_board();
    }

    int Turn(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Player " + chance + "'s turn;\nChoose the position:");
        int position = sc.nextInt();
        return position;
    }
	
    void GameLoop(){
        chance = 1;
        while(true){
            switch(chance){
                case 1:{
                    symbol = "X";
                    int position = Turn();
                    if(!tic_board.checkOccupancy(position)){
                        tic_board.setPosition(position,symbol);
                        chance = 2;
                    }
                    else{
                        System.out.println("The entered position is already filled. Try again!");
                        chance = 1;
                    }
                    break;
                }
                case 2:{
                    symbol = "O";
                    int position = Turn();
                    if(!tic_board.checkOccupancy(position)){
                        tic_board.setPosition(position,symbol);
                        chance = 1;
                    }
                    else{
                        System.out.println("The entered position is already filled. Try again!");
                        chance = 2;
                    }
                    break;
                }
                default: break;
            }
            tic_board.display();
            int outcome = tic_board.checkWinner();
            
            switch(outcome){
                case -1:{
                    break;
                }
                case 0:{
                    System.out.println("The game is a draw!");
                    return;
                }
                case 1:{
                    System.out.println("Player 1 has won the game. Congratulations!");
                    return;
                }
                case 2:{
                    System.out.println("Player 2 has won the game. Congratulations!");
                    return;
                }
            }
        }
    }		
}