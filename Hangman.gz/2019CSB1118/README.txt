// ReadMe
Word Guessing game like Hangman is a game involving making or selection of words. 
In this code, I tried to make it realistic game. In this code, I used the set of words(given), out of which randomly a word is choosen and then the player has to guess it. 
If guess is wrong, it will pass but if worng, hangman will be increamented. 
HangmanDisplay is one subroutine which I made. I choosed maximum guesses a person can make to be 6(Hangman Number). If the guess made is wrong, it will increment the form of hangman.
After that I made the main part of the game. I am new in perl. 
So, to use various new features wont be easy thing. But, I used "OUTER".  It has a label�OUTER�so that inside the loop you can have some fine-grained control over it. 
It continues looping until the number of wrong guesses is the same as the length of the hangman(hangman number; which i used as <7). 
If player makes more than 6 gusses control of while loop goes out and line "Better luck next time is displayed" with the final state of hangman.

//How to play the game?

Player has to just enter a word of its choice.
This choice or entered letter is stored in varible $guess. After this is entered, it will compare first to see if its not already entered or not. If it is already entered, $times is incremented
to 1. When $times = 1, wrong is not incremented rather $times is made = 0. Moving on, if its not already entered then it checks whether our secret word has this letter or not; if yes then it will
place that letter in that very place using @blankword*.Then display it, along with current state of hangman. If wrong, no change in word part but hangman is changed respective to the $wrong's value.
This is done till  either game is won or the wrong guesses exceed 6. After one game, it asks the player whether, he wants to continue or not. Input is in form of "y" for 'yes' and "n" for 'no'.
Accoridngly, the game proceeds in further way.

* @blankword contains 0's in place of letters of the secret word. This is done in line @blankword=(0) x scalar(@letters). Later, these 0's is replaced with dashes or letters which are being entered
by the player and are also in the secret word.
Secret word is the randomly choosen word using the rand from the given array @words.

For Example:
$choices (contains secret word) = vampire;
@letters(@letters=split(//, $choices)Splits the given word.) = v a m p i r e;
@blankword = 0 0 0 0 0 0 0;
After, first = changes to ------- and printed; Later, placed dashed is replaced with letter; Let, $guess(input variable) = a; it will print -a-----;

HangmanDisplay is a subroutine function which takes arguement as $wrong.

Explanation of the Hangman display on basis of $wrong value(easy way):
|-----        |-----        |-----        |-----        |-----        |-----        |-----                       
|	      |    O        |    O        |    O        |    O        |    O        |    O                   
|	      |             |    |        |   /|        |   /|\       |   /|\       |   /|\                           
|             |             |    |        |    |        |    |        |    |        |    |                     
|             |             |             |             |             |   /         |   / \       
$wrong = 0      $wrong = 1    $wrong = 2    $wrong = 3    $wrong = 4     $wrong= 5    $wrong = 6

Rest all I have commented briefly in the code itself so that coding style can be understoond.
 
 
 