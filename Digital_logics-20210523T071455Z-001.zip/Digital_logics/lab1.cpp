#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int N;

//extra function
int check(char *part){
	int dec = 0;
	if(part[0] == '1'){
		TwoSCompliment(A,A);
		for(int i = 1;i<N;i++){
			int bit = (int)(A[i]-'0');
			dec+= (int)(bit*pow(2,N-1-i));
		}
		dec=-dec;
	}
	else{
		for(int i = 1;i<N;i++){
			int bit = (int)(A[i]-'0');
			dec+= (int)(bit*pow(2,N-1-i));
		}
	}
	return dec;
}

void BitAddition(char A, char B, char CIN, char &Sum, char &COUT){
    int num_A = (int)(A-'0');
    int num_B = (int)(B-'0');
    int num_CIN =(int)(CIN -'0');
    if(num_A + num_B + num_CIN == 0){
        Sum = '0';
        COUT = '0';
    }
    else if(num_A + num_B + num_CIN == 1){
        Sum = '1';
        COUT = '0';
    }
    else if(num_A + num_B + num_CIN == 2){
        Sum = '0';
        COUT = '1';
    }
    else{
        Sum = '1';
        COUT = '1';
    }
}
void NBitAddition(char *A,char *B,char CIN,char *Sum,char &COUT){
    for(int i = N-1;i>=0;i--){
        BitAddition(A[i],B[i],CIN,Sum[i],COUT);
        CIN = COUT;
    }
    //isOverflow(A,B,&Sum,COUT,'0'); 
}
void Inverse(char* A, char* B){
    for(int i = 0;i<N;i++){
        B[i] = (char)(!(int)(A[i] - '0') + (int)('0')); 
    }
}
void TwoSCompliment(char* A, char *B){
	char temp[N+1];
	temp[N] = '\0';
    Inverse(A,temp);
    char COUT = '0';
    char W[N+1]; 
    for(int i = 0;i<N+1;i++){
        W[i] = '0';
        if(i == N-1){
            W[i] = '1';  
        }
        if(i == N){
            W[i] = '\0';
        }
    }
    NBitAddition(temp,W,'0',B,COUT);
}
bool isOverflow(char* A, char* B, char* Sum, char COUT, int operation){
    if(operation == 1){
        if(A[0]!= B[0]  && COUT == '1'){
            return true;
        }
        else if(check(A)-check(B)!=check(Sum)){
        	return true;
		}
    
        else{
            return false;
        }
    }
    else{
        if(A[0]!= B[0]){
            return false;
        }
        else if(A[0] == B[0] && Sum[0]!= A[0] && Sum[0]!= B[0]){
            return true;
        }
        else{
            return false;
        }
    }
    int upl = (int)(pow(2,N-1)-1);
    int lpl = -(int)(pow(2,N-1));
    if(check(A)>upl || check(B)>upl || check(A)<lpl || check(B)<lpl){
    	return true;
	}
    

}
vvoid NBitSubtraction(char* A, char* B, char CIN, char* Sum, char &COUT){
    char temp_arr[N];
    if(CIN == '1'){
        Inverse(B, temp_arr);
        NBitAddition(A, temp_arr, '0', Sum, COUT);
    }
    else 
        if(CIN == '0'){
            TwoSCompliment(B, temp_arr);
            NBitAddition(A, temp_arr, '0', Sum, COUT);
        }
}
    //isOverflow(A,B,Sum,COUT,'1');
    /*if(A[0] == '1' && B[0] == '0'){
        TwoSCompliment(A,A);
        NBitAddition(A,B,CIN,&Sum,COUt);
    }
    else if(A[0] == '1' && B[0] == '1'){
        TwoSCompliment(B,B);
         NBitAddition(A,B,CIN,&Sum,COUt);
    }
     else{
        TwoSCompliment(A,A);
        TwoSCompliment(B,B);
         NBitAddition(A,B,CIN,&Sum,COUt);
        isOverflow(A,B,&Sum,COUT,'1');
    }*/
}

int main(){
    cin>>N;
    char A[N+1];
    A[N] = {'\0'};
    char B[N+1];
    B[N] = {'\0'};
    char Sum[N+1];
    Sum[N] = {'\0'};
    char CIN,COUT;
    char S;
    char R;
    char Z;
    cin>>S>>R>>CIN;
    BitAddition(S,R,CIN,Z,COUT);
    cout<<Z<<" "<<COUT<<endl;
    //NBitAddition
    for(int i = 0;i<N;i++){
        cin>>A[i];
    }
    for(int i = 0;i<N;i++){
        cin>>B[i];
    }
    cin>>CIN;
    NBitAddition(A,B,CIN,Sum,COUT);
    for(int i = 0;i<N;i++ ){
        cout<<Sum[i];
    }
    cout<<" "<<COUT<<endl;
    //Inverse
    for(int i = 0;i<N;i++){
        cin>>A[i];
    }
    Inverse(A,B);
    for(int i = 0;i<N;i++){
        cout<<B[i];
    }
    cout<<"\n";
    //TwoSCompliment
    for(int i = 0;i<N;i++){
        cin>>A[i];
    }
    TwoSCompliment(A,B);
    for(int i = 0;i<N;i++){
        cout<<B[i];
    }
    cout<<"\n";
    //isOverflow
    bool isOverFlow;//while the function name is isOverflow
    for(int i = 0;i<N;i++){
        cin>>A[i];
    }
    for(int i = 0;i<N;i++){
        cin>>B[i];
    }
    int operation;
    cin>>operation;
    if(operation == 0){
    	NBitAddition(A,B,'0',Sum,COUT);
    	isOverFlow = isOverflow(A,B,Sum,COUT,operation);
	}
	else{
		NBitSubtraction(A,B,'0',Sum,COUT);
    	isOverFlow = isOverflow(A,B,Sum,COUT,operation);
	}
    if(isOverFlow == true){
        cout<<"1\n";
    }
    else{
        cout<<"0\n";
    }
    //NBitSubtraction
    for(int i = 0;i<N;i++){
        cin>>A[i];
    }
    for(int i = 0;i<N;i++){
        cin>>B[i];
    }
    cin>>CIN;
    NBitSubtraction(A,B,CIN,Sum,COUT);
    for(int o = 0;o<N;o++){
        cout<<Sum[o];
    }
    cout<<" "<<COUT<<endl;
    
    return 0;
}


