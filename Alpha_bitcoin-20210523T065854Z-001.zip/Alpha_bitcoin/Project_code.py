import networkx as nx
import numpy as np
import random as rand
import matplotlib.pyplot as plt

# opened the file
f=open("bitcoin.csv",'r')
#reading lines
f=f.readlines()

#we converted it to list
l=list(f)

#declared a list
g=[]

#editing the list so that there are only three columns in the resulting list 
for i in range(len(l)):
    a=l[i].split(',')
    g.append([int(a[0]),int(a[1]),int(a[2])])
# sorted the list according to first column
g.sort(key = lambda x: x[1])
#key is the target note.
dict={}
for i in g:
    #5 is the rating
    #the nodes greater than 50 were getting less influenced.
    if i[2]>=5 and i[1]<=50:
        if i[1] in dict:
            dict[i[1]][0]+=1
            dict[i[1]][1].add(i[0])
        else: 
            dict[i[1]]=[1,{i[0]}]
#print(dict)
ls=[]#[counter,node]
for i in dict:
    # add the number of the influenced nodes and that node
    ls.append([dict[i][0],i])
#sort the list in reverse order
ls.sort(reverse=True)
#superset containing the set of the influenced nodes.
spset=set()
#list for storing the maximum connected nodes
lr=[]
#new dict because old dict will be appended later 
dict1 = dict.copy()
#main part 
for i in range(10):
    if len(spset)==0:
        # a is the influencing node For example [95,3] then a is 3
        a=ls[0][1]
        lr.append(a)
        #stored the set of influenced nodes from the dict correspoding to a in the spset.
        for i in dict[a][1]:
            spset.add(i)
        '''print('\n')
        print(ls)
        print('\n')'''
        #then removing that node which is at postion 0 in ls.
        ls.remove(ls[0])
        #deleting the information of a in dict
        del dict[a]
    else:
        #deleteing the old list
        del ls
        ls=[]
        #subtracting the comman connections
        for j in dict:
            dict[j][1]=dict[j][1]-spset
            dict[j][0]=len(dict[j][1])
            ls.append([len(dict[j][1]),j])
        #sorting in the reverse order
        ls.sort(reverse=True)
        a=ls[0][1]
        lr.append(a)
        for i in dict[a][1]:
            spset.add(i)
        '''print('\n')
        print(ls)
        print('\n')'''
        #then removing that node which is at postion 0 in ls.
        ls.remove(ls[0])
        #deleting the information of a in dict
        del dict[a]
#final result
#the list of the most connected nodes
#nodes having the most connections
print(lr)
#print(spset)
def make_Graph(lr,spset):
    G = nx.DiGraph()#directed graph 
    colour_list = []#for the colors 
    for i in dict1:
        #G.add_node(i)
        s = dict1[i][1]#adding edges and nodes to the graph 
        for j in s:
            #G.add_node(j)
            G.add_edge(j,i)
    #pos = nx.kamada_kawai_layout(G)
    #nx.draw(G.pos1,with_labels = True)
    for i in G.nodes():
        if i in lr:
            colour_list.append("red")#main nodes
        elif i in spset:
            colour_list.append("cyan")#sp set nodes
        else:
            colour_list.append("yellow")#rest of the nodes
    #this had a better presentation value 
    pos = nx.random_layout(G)
    nx.draw(G,pos,with_labels = True)#labeled graph 
    nx.draw_networkx_nodes(G, pos,node_color=colour_list)
    #nx.draw_networkx_nodes(G,pos,nodelist = list(spset),node_color = "g")
    plt.show()
    
#function call
make_Graph(lr,spset)
